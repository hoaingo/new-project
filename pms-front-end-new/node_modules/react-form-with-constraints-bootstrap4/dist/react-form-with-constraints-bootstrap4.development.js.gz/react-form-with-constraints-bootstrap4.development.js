(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('react'), require('prop-types'), require('react-form-with-constraints')) :
	typeof define === 'function' && define.amd ? define(['exports', 'react', 'prop-types', 'react-form-with-constraints'], factory) :
	(factory((global.ReactFormWithConstraintsBootstrap4 = {}),global.React,global.PropTypes,global.ReactFormWithConstraints));
}(this, (function (exports,React,PropTypes,reactFormWithConstraints) { 'use strict';

/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = Object.setPrototypeOf ||
    ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
    function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };

function __extends(d, b) {
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = Object.assign || function __assign(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
};

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) if (e.indexOf(p[i]) < 0)
            t[p[i]] = s[p[i]];
    return t;
}















function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

var FormGroup = (function (_super) {
    __extends(FormGroup, _super);
    function FormGroup(props) {
        var _this = _super.call(this, props) || this;
        _this.reRender = _this.reRender.bind(_this);
        return _this;
    }
    FormGroup.prototype.componentWillMount = function () {
        this.context.form.addValidateEventListener(this.reRender);
    };
    FormGroup.prototype.componentWillUnmount = function () {
        this.context.form.removeValidateEventListener(this.reRender);
    };
    FormGroup.prototype.reRender = function (input) {
        var fieldName = this.props.for;
        if (input.name === fieldName) {
            this.forceUpdate();
        }
    };
    FormGroup.prototype.className = function (fieldName) {
        var className = 'form-group';
        if (fieldName !== undefined) {
            var form = this.context.form;
            if (form.fieldsStore.containErrors(fieldName)) {
                className += ' has-danger';
            }
            else if (form.fieldsStore.containWarnings(fieldName)) {
                className += ' has-warning';
            }
            else if (form.fieldsStore.areValidDirtyWithoutWarnings(fieldName)) {
                className += ' has-success';
            }
        }
        return className;
    };
    FormGroup.prototype.render = function () {
        var _a = this.props, fieldName = _a.for, className = _a.className, children = _a.children, divProps = __rest(_a, ["for", "className", "children"]);
        var classes = className !== undefined ? className + " " + this.className(fieldName) : this.className(fieldName);
        return (React.createElement("div", __assign({}, divProps, { className: classes }), children));
    };
    FormGroup.contextTypes = {
        form: PropTypes.object.isRequired
    };
    return FormGroup;
}(React.Component));
var FormControlLabel = function (props) {
    var className = props.className, children = props.children, labelProps = __rest(props, ["className", "children"]);
    var classes = className !== undefined ? className + " form-control-label" : 'form-control-label';
    return (React.createElement("label", __assign({}, labelProps, { className: classes }), children));
};
var FormControlInput = (function (_super) {
    __extends(FormControlInput, _super);
    function FormControlInput(props) {
        var _this = _super.call(this, props) || this;
        _this.reRender = _this.reRender.bind(_this);
        return _this;
    }
    FormControlInput.prototype.componentWillMount = function () {
        this.context.form.addValidateEventListener(this.reRender);
    };
    FormControlInput.prototype.componentWillUnmount = function () {
        this.context.form.removeValidateEventListener(this.reRender);
    };
    FormControlInput.prototype.reRender = function (input) {
        var fieldName = this.props.name;
        if (input.name === fieldName) {
            this.forceUpdate();
        }
    };
    FormControlInput.prototype.className = function (name) {
        var className = 'form-control';
        if (name !== undefined) {
            var form = this.context.form;
            if (form.fieldsStore.containErrors(name)) {
                className += ' form-control-danger';
            }
            else if (form.fieldsStore.containWarnings(name)) {
                className += ' form-control-warning';
            }
            else if (form.fieldsStore.areValidDirtyWithoutWarnings(name)) {
                className += ' form-control-success';
            }
        }
        return className;
    };
    FormControlInput.prototype.render = function () {
        var _a = this.props, innerRef = _a.innerRef, className = _a.className, children = _a.children, inputProps = __rest(_a, ["innerRef", "className", "children"]);
        var classes = className !== undefined ? className + " " + this.className(inputProps.name) : this.className(inputProps.name);
        return (React.createElement("input", __assign({ ref: innerRef }, inputProps, { className: classes })));
    };
    FormControlInput.contextTypes = {
        form: PropTypes.object.isRequired
    };
    return FormControlInput;
}(React.Component));
var FieldFeedbacks$1 = function (props) {
    var className = props.className, children = props.children, other = __rest(props, ["className", "children"]);
    var classes = className !== undefined ? className + " form-control-feedback" : 'form-control-feedback';
    return React.createElement(reactFormWithConstraints.FieldFeedbacks, __assign({}, other, { className: classes }), children);
};
var LabelWithFormControlStyle = (function (_super) {
    __extends(LabelWithFormControlStyle, _super);
    function LabelWithFormControlStyle(props) {
        var _this = _super.call(this, props) || this;
        _this.reRender = _this.reRender.bind(_this);
        return _this;
    }
    LabelWithFormControlStyle.prototype.componentWillMount = function () {
        this.context.form.addValidateEventListener(this.reRender);
    };
    LabelWithFormControlStyle.prototype.componentWillUnmount = function () {
        this.context.form.removeValidateEventListener(this.reRender);
    };
    LabelWithFormControlStyle.prototype.reRender = function (input) {
        var fieldNames = this.props.for;
        if (fieldNames.includes(input.name)) {
            this.forceUpdate();
        }
    };
    LabelWithFormControlStyle.prototype.render = function () {
        var _a = this.props, fieldNames = _a.for, style = _a.style, children = _a.children, labelProps = __rest(_a, ["for", "style", "children"]);
        var form = this.context.form;
        var brandDanger = '#d9534f';
        var brandWarning = '#f0ad4e';
        var brandSuccess = '#5cb85c';
        var color;
        if ((_b = form.fieldsStore).containErrors.apply(_b, __spread(fieldNames))) {
            color = brandDanger;
        }
        else if ((_c = form.fieldsStore).containWarnings.apply(_c, __spread(fieldNames))) {
            color = brandWarning;
        }
        else if ((_d = form.fieldsStore).areValidDirtyWithoutWarnings.apply(_d, __spread(fieldNames))) {
            color = brandSuccess;
        }
        var styles = style !== undefined ? __assign({ color: color }, style) : { color: color };
        return (React.createElement("label", __assign({}, labelProps, { style: styles }), children));
        var _b, _c, _d;
    };
    LabelWithFormControlStyle.contextTypes = {
        form: PropTypes.object.isRequired
    };
    return LabelWithFormControlStyle;
}(React.Component));

exports.FormGroup = FormGroup;
exports.FormControlLabel = FormControlLabel;
exports.FormControlInput = FormControlInput;
exports.FieldFeedbacks = FieldFeedbacks$1;
exports.LabelWithFormControlStyle = LabelWithFormControlStyle;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=react-form-with-constraints-bootstrap4.development.js.map
